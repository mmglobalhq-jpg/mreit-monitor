"""
API routes for health checks, manual triggers, and status queries.
"""

import logging
from datetime import datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()
logger = logging.getLogger("mreit-monitor.api")


class HealthResponse(BaseModel):
    status: str
    timestamp: str
    environment: str


class TriggerResponse(BaseModel):
    status: str
    message: str
    filings_found: int = 0


class FilingStatusResponse(BaseModel):
    ticker: str
    filing_type: str
    period_label: str
    status: str
    filing_date: str
    processed_at: str | None = None


# ============================================================================
# Health
# ============================================================================

@router.get("/health", response_model=HealthResponse)
async def health_check():
    from src.config.settings import settings
    return HealthResponse(
        status="ok",
        timestamp=datetime.utcnow().isoformat(),
        environment=settings.environment,
    )


# ============================================================================
# Manual Triggers
# ============================================================================

@router.post("/trigger/poll/{ticker}", response_model=TriggerResponse)
async def trigger_poll(ticker: str):
    """Manually trigger a poll for a specific company."""
    # TODO: Implement — call the scraper for the given ticker
    logger.info("Manual poll triggered for %s", ticker.upper())
    raise HTTPException(status_code=501, detail="Not yet implemented")


@router.post("/trigger/process")
async def trigger_process(source_url: str, filing_type: str = "monthly_update"):
    """Manually process a specific filing by URL."""
    # TODO: Implement — download and process a specific filing
    logger.info("Manual process triggered for %s", source_url)
    raise HTTPException(status_code=501, detail="Not yet implemented")


@router.post("/trigger/backfill/{ticker}", response_model=TriggerResponse)
async def trigger_backfill(ticker: str):
    """Trigger historical backfill for a company."""
    # TODO: Implement — run backfill script for the ticker
    logger.info("Backfill triggered for %s", ticker.upper())
    raise HTTPException(status_code=501, detail="Not yet implemented")


# ============================================================================
# Status Queries
# ============================================================================

@router.get("/status/latest/{ticker}")
async def get_latest_filing(ticker: str):
    """Get the most recently processed filing for a company."""
    # TODO: Implement — query filings table
    raise HTTPException(status_code=501, detail="Not yet implemented")


@router.get("/status/filings/{ticker}")
async def list_filings(ticker: str, filing_type: str | None = None, limit: int = 20):
    """List processed filings for a company."""
    # TODO: Implement — query filings table with filters
    raise HTTPException(status_code=501, detail="Not yet implemented")
