"""
Earnings release parser — processes quarterly earnings press releases.

Pipeline:
1. Download HTML press release page
2. Extract text content with BeautifulSoup
3. Send to Claude for structured extraction
4. Validate and store in quarterly_metrics table
5. Run quarterly comparison agent
6. Send email alert

TODO: Implement (Phase 2)
"""
