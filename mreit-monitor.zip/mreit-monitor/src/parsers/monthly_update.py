"""
Monthly update parser — orchestrates the full processing pipeline
for a single monthly company update PDF.

Pipeline:
1. Download PDF
2. Upload to Supabase Storage
3. Send to Claude for structured extraction
4. Validate and store extracted data in Supabase
5. Run comparison agent against prior month
6. Send email alert
7. Update filing status
"""

import json
import logging
from datetime import date, datetime

from src.models.schemas import FilingStatus, FilingType, MonthlyUpdateExtraction
from src.services.supabase_client import get_supabase_client

logger = logging.getLogger("mreit-monitor.monthly_parser")


async def process_monthly_update(
    company_id: str,
    company_name: str,
    ticker: str,
    source_url: str,
    filing_date: date,
    period_label: str,
) -> bool:
    """
    Full pipeline for processing a single monthly update PDF.
    
    Returns True if processing completed successfully.
    """
    from src.services.downloader import download_pdf, upload_to_storage, build_storage_path
    from src.agents.extraction_agent import extract_monthly_update
    from src.agents.comparison_agent import generate_monthly_comparison
    from src.services.email_service import send_filing_alert
    
    client = get_supabase_client()
    filing_id = None
    
    try:
        # ============================================================
        # Step 1: Create filing record
        # ============================================================
        filing_record = {
            "company_id": company_id,
            "filing_type": FilingType.MONTHLY_UPDATE.value,
            "status": FilingStatus.DETECTED.value,
            "source_url": source_url,
            "source_page": "monthly_company_updates",
            "filing_date": filing_date.isoformat(),
            "period_label": period_label,
        }
        result = client.table("filings").insert(filing_record).execute()
        filing_id = result.data[0]["id"]
        logger.info("Created filing record %s for %s %s", filing_id, ticker, period_label)
        
        # ============================================================
        # Step 2: Download PDF
        # ============================================================
        pdf_bytes = await download_pdf(source_url)
        
        # ============================================================
        # Step 3: Upload to Supabase Storage
        # ============================================================
        storage_path = build_storage_path(ticker, "monthly_update", period_label)
        await upload_to_storage(pdf_bytes, storage_path)
        
        client.table("filings").update({
            "status": FilingStatus.DOWNLOADED.value,
            "storage_path": storage_path,
            "downloaded_at": datetime.utcnow().isoformat(),
        }).eq("id", filing_id).execute()
        
        # ============================================================
        # Step 4: Extract structured data via Claude
        # ============================================================
        client.table("filings").update({
            "status": FilingStatus.EXTRACTING.value,
        }).eq("id", filing_id).execute()
        
        # Get prior month's footnotes for change detection
        prior_footnotes = _get_prior_footnotes(client, company_id)
        
        extraction, extraction_meta = await extract_monthly_update(pdf_bytes, prior_footnotes)
        
        client.table("filings").update({
            "status": FilingStatus.EXTRACTED.value,
            "extraction_model": extraction_meta["model"],
            "extraction_tokens_used": extraction_meta["input_tokens"] + extraction_meta["output_tokens"],
            "raw_extraction_json": json.loads(extraction_meta["raw_response"]),
            "extracted_at": datetime.utcnow().isoformat(),
        }).eq("id", filing_id).execute()
        
        # ============================================================
        # Step 5: Store structured data in Supabase tables
        # ============================================================
        await _store_monthly_data(client, filing_id, company_id, extraction)
        
        logger.info("Stored structured data for %s %s", ticker, period_label)
        
        # ============================================================
        # Step 6: Run comparison agent
        # ============================================================
        client.table("filings").update({
            "status": FilingStatus.COMPARING.value,
        }).eq("id", filing_id).execute()
        
        prior_data = _get_prior_monthly_data(client, company_id, extraction.data_as_of_date)
        
        analysis = None
        if prior_data:
            current_data = extraction.model_dump()
            analysis, comparison_meta = await generate_monthly_comparison(
                company_name=company_name,
                ticker=ticker,
                current_period=period_label,
                prior_period=prior_data["period_label"],
                current_data=current_data,
                prior_data=prior_data["data"],
            )
            
            # Store analysis
            client.table("agent_analyses").insert({
                "filing_id": filing_id,
                "company_id": company_id,
                "analysis_type": "monthly_comparison",
                "period_label": f"{period_label} vs {prior_data['period_label']}",
                "summary": analysis.summary,
                "full_analysis": analysis.full_analysis,
                "key_changes": [c.model_dump() for c in analysis.key_metric_changes],
                "anomalies": [a.model_dump() for a in analysis.anomalies],
                "current_period_date": extraction.data_as_of_date,
                "prior_period_date": prior_data["as_of_date"],
                "model_used": comparison_meta["model"],
                "tokens_used": comparison_meta["input_tokens"] + comparison_meta["output_tokens"],
            }).execute()
            
            logger.info("Comparison analysis stored for %s %s", ticker, period_label)
        else:
            logger.info("No prior month data for comparison — skipping comparison agent")
        
        # ============================================================
        # Step 7: Send email alert
        # ============================================================
        metrics_summary = _build_metrics_summary(extraction, prior_data)
        
        await send_filing_alert(
            ticker=ticker,
            company_name=company_name,
            filing_type_label="Monthly Update",
            period_label=period_label,
            source_url=source_url,
            analysis=analysis,
            metrics_summary=metrics_summary,
        )
        
        # ============================================================
        # Step 8: Mark complete
        # ============================================================
        client.table("filings").update({
            "status": FilingStatus.COMPLETED.value,
            "completed_at": datetime.utcnow().isoformat(),
        }).eq("id", filing_id).execute()
        
        logger.info("Successfully processed %s %s monthly update", ticker, period_label)
        return True
        
    except Exception as e:
        logger.error("Failed to process %s %s: %s", ticker, period_label, str(e))
        if filing_id:
            client.table("filings").update({
                "status": FilingStatus.EXTRACTION_FAILED.value,
                "error_message": str(e)[:1000],
            }).eq("id", filing_id).execute()
        raise


async def _store_monthly_data(
    client,
    filing_id: str,
    company_id: str,
    extraction: MonthlyUpdateExtraction,
) -> None:
    """Store all extracted monthly data into the appropriate Supabase tables."""
    
    as_of_date = extraction.data_as_of_date
    
    # Monthly metrics (headline numbers)
    metrics = {
        "filing_id": filing_id,
        "company_id": company_id,
        "as_of_date": as_of_date,
        "stock_price": extraction.key_metrics.stock_price,
        "debt_equity": extraction.key_metrics.debt_equity,
        "implied_leverage": extraction.key_metrics.implied_leverage,
        "liquidity_millions": extraction.key_metrics.liquidity_millions,
        "liquidity_pct_capital": extraction.key_metrics.liquidity_pct_capital,
        "market_cap_millions": extraction.key_metrics.market_cap_millions,
        "monthly_dividend": extraction.dividend_info.monthly_dividend,
        "dividend_yield": extraction.dividend_info.dividend_yield,
    }
    
    # Add portfolio totals from the subtotal rows
    for pos in extraction.portfolio_positions:
        if pos.security_type == "Total Portfolio" or (pos.is_subtotal and "total" in pos.security_type.lower()):
            metrics["total_portfolio_value_millions"] = pos.market_value_millions
        elif pos.security_type == "Agency Portfolio" or (pos.is_subtotal and "agency" in pos.security_type.lower()):
            metrics["agency_portfolio_pct"] = pos.pct_portfolio
            metrics["agency_portfolio_value_millions"] = pos.market_value_millions
    
    # Upsert monthly metrics (unique on company_id + as_of_date)
    client.table("monthly_metrics").upsert(metrics, on_conflict="company_id,as_of_date").execute()
    
    # Portfolio positions
    for pos in extraction.portfolio_positions:
        client.table("portfolio_positions").insert({
            "filing_id": filing_id,
            "company_id": company_id,
            "as_of_date": as_of_date,
            "security_type": pos.security_type,
            "coupon": pos.coupon,
            "is_subtotal": pos.is_subtotal,
            "parent_category": pos.parent_category,
            "pct_portfolio": pos.pct_portfolio,
            "market_value_millions": pos.market_value_millions,
            "effective_duration": pos.effective_duration,
        }).execute()
    
    # Repo positions
    for repo in extraction.repo_positions:
        client.table("repo_positions").insert({
            "filing_id": filing_id,
            "company_id": company_id,
            "as_of_date": as_of_date,
            "counterparty": repo.counterparty,
            "is_affiliate": repo.is_affiliate,
            "is_total": repo.is_total,
            "principal_borrowed_millions": repo.principal_borrowed_millions,
            "pct_of_repo": repo.pct_of_repo,
            "wtd_avg_original_term_days": repo.wtd_avg_original_term_days,
            "wtd_avg_remaining_term_days": repo.wtd_avg_remaining_term_days,
            "longest_maturity_days": repo.longest_maturity_days,
        }).execute()
    
    # Swap positions
    for swap in extraction.swap_positions:
        client.table("swap_positions").insert({
            "filing_id": filing_id,
            "company_id": company_id,
            "as_of_date": as_of_date,
            "maturity_bucket": swap.maturity_bucket,
            "is_total": swap.is_total,
            "notional_millions": swap.notional_millions,
            "wtd_avg_remaining_term_months": swap.wtd_avg_remaining_term_months,
            "wtd_avg_rate": swap.wtd_avg_rate,
        }).execute()
    
    # Footnotes
    for fn in extraction.footnotes:
        # Check for changes from prior footnotes
        changed = False
        prior_text = None
        # TODO: Compare with prior month's footnotes
        
        client.table("filing_footnotes").insert({
            "filing_id": filing_id,
            "company_id": company_id,
            "as_of_date": as_of_date,
            "footnote_number": fn.number,
            "footnote_text": fn.text,
            "changed_from_prior": changed,
            "prior_text": prior_text,
        }).execute()


def _get_prior_footnotes(client, company_id: str) -> list[dict] | None:
    """Get the most recent footnotes for a company."""
    result = (
        client.table("filing_footnotes")
        .select("footnote_number, footnote_text")
        .eq("company_id", company_id)
        .order("as_of_date", desc=True)
        .limit(10)
        .execute()
    )
    return result.data if result.data else None


def _get_prior_monthly_data(client, company_id: str, current_as_of: str) -> dict | None:
    """Get the prior month's complete data for comparison."""
    # Get the most recent monthly metrics before current_as_of
    result = (
        client.table("monthly_metrics")
        .select("*")
        .eq("company_id", company_id)
        .lt("as_of_date", current_as_of)
        .order("as_of_date", desc=True)
        .limit(1)
        .execute()
    )
    
    if not result.data:
        return None
    
    prior_metrics = result.data[0]
    prior_filing_id = prior_metrics["filing_id"]
    prior_as_of = prior_metrics["as_of_date"]
    
    # Get the prior period's raw extraction JSON from the filings table
    filing_result = (
        client.table("filings")
        .select("raw_extraction_json, period_label")
        .eq("id", prior_filing_id)
        .limit(1)
        .execute()
    )
    
    if not filing_result.data or not filing_result.data[0].get("raw_extraction_json"):
        return None
    
    return {
        "as_of_date": prior_as_of,
        "period_label": filing_result.data[0]["period_label"],
        "data": filing_result.data[0]["raw_extraction_json"],
    }


def _build_metrics_summary(
    extraction: MonthlyUpdateExtraction,
    prior_data: dict | None,
) -> list[dict]:
    """Build a summary of key metrics with deltas for the email alert."""
    metrics = [
        ("Stock Price", extraction.key_metrics.stock_price, "$"),
        ("Debt/Equity", extraction.key_metrics.debt_equity, "x"),
        ("Implied Leverage", extraction.key_metrics.implied_leverage, "x"),
        ("Liquidity ($M)", extraction.key_metrics.liquidity_millions, ""),
        ("Liquidity % Capital", extraction.key_metrics.liquidity_pct_capital, "%"),
        ("Monthly Dividend", extraction.dividend_info.monthly_dividend, "$"),
        ("Dividend Yield", extraction.dividend_info.dividend_yield, "%"),
    ]
    
    summary = []
    for name, current_val, suffix in metrics:
        entry = {"name": name, "current": f"{current_val}{suffix}" if current_val else "—"}
        
        # TODO: Look up prior value from prior_data for delta calculation
        entry["prior"] = "—"
        entry["delta_str"] = "—"
        entry["direction"] = "flat"
        
        summary.append(entry)
    
    return summary
