"""
Quarterly filing parser — processes 10-Q and 10-K PDFs.

For these 100+ page documents, uses pdfplumber to extract key sections
(financial statements, investment schedule, derivatives, MD&A),
then sends each section to Claude individually for extraction.

TODO: Implement (Phase 2)
"""
