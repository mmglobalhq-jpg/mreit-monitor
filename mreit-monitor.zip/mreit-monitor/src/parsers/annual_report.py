"""
Annual report parser — processes annual reports, proxies, and 10-Ks.

TODO: Implement (Phase 3)
"""
