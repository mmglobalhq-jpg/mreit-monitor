"""
APScheduler setup for daily polling.

Runs inside the FastAPI lifespan context.
Polls company IR pages and SEC EDGAR for new filings once daily.
"""

import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from src.config.settings import settings

logger = logging.getLogger("mreit-monitor.scheduler")


async def poll_all_companies():
    """
    Main scheduled job: poll all active companies for new filings.
    
    Steps:
    1. Query the companies table for all active companies
    2. For each company, scrape their IR pages for new PDF/HTML links
    3. For each company, check EDGAR submissions API for new filings
    4. For any new filings found, trigger the download + extraction pipeline
    """
    logger.info("Starting daily poll for all active companies...")
    
    # TODO: Implement
    # 1. Get active companies from Supabase
    # 2. For each company, call scraper.scrape_company(company)
    # 3. For each company, call edgar.check_new_filings(company)
    # 4. For each new filing found, call pipeline.process_filing(filing)
    
    logger.info("Daily poll complete.")


def start_scheduler() -> AsyncIOScheduler:
    """Create and start the scheduler with the daily poll job."""
    scheduler = AsyncIOScheduler()
    
    # Daily poll at configured time
    scheduler.add_job(
        poll_all_companies,
        CronTrigger(
            hour=settings.poll_hour,
            minute=settings.poll_minute,
            timezone=settings.poll_timezone,
        ),
        id="daily_poll",
        name="Daily mREIT filing poll",
        replace_existing=True,
    )
    
    scheduler.start()
    return scheduler


def shutdown_scheduler(scheduler: AsyncIOScheduler):
    """Gracefully shut down the scheduler."""
    scheduler.shutdown(wait=False)
    logger.info("Scheduler shut down.")
