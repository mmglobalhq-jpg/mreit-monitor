"""
IR page scraper for detecting new filings on company investor relations pages.

Scrapes the monthly updates, quarterly reports, annual reports, and news pages
for each configured company. Compares found links against the filings table in
Supabase to identify new documents that need processing.
"""

import logging
from dataclasses import dataclass
from datetime import date

import httpx
from bs4 import BeautifulSoup

from src.models.schemas import FilingType

logger = logging.getLogger("mreit-monitor.scraper")


@dataclass
class DetectedFiling:
    """A filing detected by the scraper but not yet downloaded."""
    source_url: str
    filing_type: FilingType
    filing_date: date
    period_label: str
    source_page: str


async def scrape_monthly_updates(
    page_url: str,
    link_pattern: str = "/static-files/",
) -> list[DetectedFiling]:
    """
    Scrape a company's monthly updates page for PDF links.
    
    For ARMOUR, the page structure is:
    - Date text (e.g., "3/13/2026")
    - Followed by an <a> tag with href containing "/static-files/{uuid}"
    - The <a> tag's title attribute has the PDF filename
    
    Args:
        page_url: URL of the monthly updates page
        link_pattern: Pattern to match in href attributes
        
    Returns:
        List of DetectedFiling objects for each PDF found
    """
    # TODO: Implement
    # 1. Fetch the page HTML with httpx
    # 2. Parse with BeautifulSoup
    # 3. Find all <a> tags with href matching link_pattern
    # 4. For each link, extract the date from the preceding text
    # 5. Build the full URL and create a DetectedFiling
    # 6. Return all detected filings
    
    logger.info("Scraping monthly updates from %s", page_url)
    
    async with httpx.AsyncClient() as client:
        response = await client.get(page_url, follow_redirects=True)
        response.raise_for_status()
    
    soup = BeautifulSoup(response.text, "lxml")
    filings = []
    
    # Find all PDF links
    for link in soup.find_all("a", href=lambda h: h and link_pattern in h):
        href = link.get("href", "")
        title = link.get("title", "")
        
        # Build absolute URL
        if href.startswith("/"):
            from urllib.parse import urljoin
            href = urljoin(page_url, href)
        
        # Extract date from nearby text
        # The date is in the parent or sibling element
        # TODO: Implement date extraction logic specific to ARMOUR's page structure
        
        # Parse period label from title attribute
        # e.g., "March 2026 Company Update (1).pdf" → "March 2026"
        period_label = _extract_period_from_title(title)
        filing_date = _extract_date_from_context(link)
        
        if filing_date and period_label:
            filings.append(DetectedFiling(
                source_url=href,
                filing_type=FilingType.MONTHLY_UPDATE,
                filing_date=filing_date,
                period_label=period_label,
                source_page=page_url,
            ))
    
    logger.info("Found %d monthly update PDFs on %s", len(filings), page_url)
    return filings


async def scrape_quarterly_reports(page_url: str) -> list[DetectedFiling]:
    """
    Scrape a company's quarterly reports page for earnings releases,
    10-Q/10-K PDFs, and investor presentations.
    
    For ARMOUR, the page is organized by year (H2) → quarter (H3),
    with links for each document type within each quarter section.
    
    Returns:
        List of DetectedFiling objects for all documents found
    """
    # TODO: Implement
    # 1. Fetch page HTML
    # 2. Parse year/quarter structure
    # 3. Within each quarter, identify:
    #    - Earnings Release links (HTML pages)
    #    - 10-Q or 10-K PDF links
    #    - Investor Presentation PDF links
    #    - Webcast links (skip these)
    # 4. Return all detected filings
    
    logger.info("Scraping quarterly reports from %s", page_url)
    return []


async def scrape_news_page(news_url: str) -> list[DetectedFiling]:
    """
    Scrape a company's news page for earnings releases and other announcements.
    
    Returns:
        List of DetectedFiling objects for news items found
    """
    # TODO: Implement
    logger.info("Scraping news from %s", news_url)
    return []


async def filter_new_filings(
    detected: list[DetectedFiling],
    company_id: str,
) -> list[DetectedFiling]:
    """
    Filter out filings that are already in the database.
    
    Checks the filings table in Supabase for existing records
    with matching company_id + source_url.
    """
    # TODO: Implement
    # 1. Get all existing source_urls for this company from Supabase
    # 2. Filter detected list to only include URLs not in the database
    
    from src.services.supabase_client import get_supabase_client
    
    client = get_supabase_client()
    existing = client.table("filings").select("source_url").eq("company_id", company_id).execute()
    existing_urls = {r["source_url"] for r in existing.data}
    
    new_filings = [f for f in detected if f.source_url not in existing_urls]
    logger.info("Found %d new filings out of %d detected", len(new_filings), len(detected))
    return new_filings


def _extract_period_from_title(title: str) -> str | None:
    """Extract period label from PDF title, e.g., 'March 2026 Company Update.pdf' → 'March 2026'."""
    # TODO: Implement robust parsing
    if not title:
        return None
    # Remove file extension and common suffixes
    name = title.replace(".pdf", "").replace("Company Update", "").replace("ARR", "").strip()
    # Try to find month + year pattern
    return name.strip() if name else None


def _extract_date_from_context(link_element) -> date | None:
    """Extract the posting date from the HTML context around a link element."""
    # TODO: Implement — look at sibling/parent text nodes for date patterns
    return None
