"""
Seed the companies table with initial company configurations.

Usage:
    python -m scripts.seed_companies

Note: The ARMOUR record is also created by the migration SQL, but this
script can be used to update the config or add new companies.
"""

import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("seed")


def seed_companies():
    """Insert or update company records from the config registry."""
    from src.config.companies import COMPANY_CONFIGS
    from src.services.supabase_client import get_supabase_client
    
    client = get_supabase_client()
    
    for ticker, config in COMPANY_CONFIGS.items():
        logger.info("Seeding %s (%s)...", ticker, config["name"])
        
        record = {
            "ticker": ticker,
            "name": config["name"],
            "cik": config["cik"],
            "exchange": config.get("exchange", "NYSE"),
            "monthly_updates_url": config.get("monthly_updates_url"),
            "quarterly_reports_url": config.get("quarterly_reports_url"),
            "annual_reports_url": config.get("annual_reports_url"),
            "news_url": config.get("news_url"),
            "is_active": True,
        }
        
        client.table("companies").upsert(record, on_conflict="ticker").execute()
        logger.info("  Done.")
    
    logger.info("Seeding complete.")


if __name__ == "__main__":
    seed_companies()
